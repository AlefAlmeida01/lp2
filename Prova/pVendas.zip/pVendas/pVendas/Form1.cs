﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace pVendas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnVerificar_Click(object sender, EventArgs e)
        {
            int n = 0;

            var auxiliar2 = Interaction.InputBox("Total do Mês: ", "Semanas: ");
            int.TryParse(auxiliar2, out n);

            int s=0;

            int[,] matrizVendas = new int[n, 4];

            for(int i = 0;i < n; i++)
            {
                for(int j=0; j < n; j++)
                {
                    if (j==0)
                    {
                        var auxiliar = Interaction.InputBox("Total do mês: ", "Semanas: ");
                        
                        if (!int.TryParse(auxiliar, out matrizVendas[i,1]))
                        {
                            MessageBox.Show("Erro");

                        }
                            s = matrizVendas[i,1];
                            Quantidade.Items.Add("Total do Mês: " +(n)+ " Semanas: " +(n)+ ".\n");
                    }
                }
            }

        }
    }
}
