﻿
namespace pIMC
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblPeso = new System.Windows.Forms.Label();
            this.BntCalc = new System.Windows.Forms.Button();
            this.TxtAltura = new System.Windows.Forms.TextBox();
            this.LblAltura = new System.Windows.Forms.Label();
            this.TxtPeso = new System.Windows.Forms.TextBox();
            this.BntLimpar = new System.Windows.Forms.Button();
            this.BntSair = new System.Windows.Forms.Button();
            this.LblResult = new System.Windows.Forms.Label();
            this.TxtResult = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // LblPeso
            // 
            this.LblPeso.AutoSize = true;
            this.LblPeso.Location = new System.Drawing.Point(77, 71);
            this.LblPeso.Name = "LblPeso";
            this.LblPeso.Size = new System.Drawing.Size(31, 13);
            this.LblPeso.TabIndex = 0;
            this.LblPeso.Text = "Peso";
            // 
            // BntCalc
            // 
            this.BntCalc.Location = new System.Drawing.Point(80, 209);
            this.BntCalc.Name = "BntCalc";
            this.BntCalc.Size = new System.Drawing.Size(75, 23);
            this.BntCalc.TabIndex = 4;
            this.BntCalc.Text = "Calcular";
            this.BntCalc.UseVisualStyleBackColor = true;
            this.BntCalc.Click += new System.EventHandler(this.BntCalc_Click);
            // 
            // TxtAltura
            // 
            this.TxtAltura.Location = new System.Drawing.Point(158, 108);
            this.TxtAltura.Name = "TxtAltura";
            this.TxtAltura.Size = new System.Drawing.Size(100, 20);
            this.TxtAltura.TabIndex = 2;
            // 
            // LblAltura
            // 
            this.LblAltura.AutoSize = true;
            this.LblAltura.Location = new System.Drawing.Point(77, 111);
            this.LblAltura.Name = "LblAltura";
            this.LblAltura.Size = new System.Drawing.Size(34, 13);
            this.LblAltura.TabIndex = 4;
            this.LblAltura.Text = "Altura";
            // 
            // TxtPeso
            // 
            this.TxtPeso.Location = new System.Drawing.Point(158, 68);
            this.TxtPeso.Name = "TxtPeso";
            this.TxtPeso.Size = new System.Drawing.Size(100, 20);
            this.TxtPeso.TabIndex = 1;
            // 
            // BntLimpar
            // 
            this.BntLimpar.Location = new System.Drawing.Point(183, 209);
            this.BntLimpar.Name = "BntLimpar";
            this.BntLimpar.Size = new System.Drawing.Size(75, 23);
            this.BntLimpar.TabIndex = 5;
            this.BntLimpar.Text = "Limpar";
            this.BntLimpar.UseVisualStyleBackColor = true;
            this.BntLimpar.Click += new System.EventHandler(this.BntLimpar_Click);
            // 
            // BntSair
            // 
            this.BntSair.Location = new System.Drawing.Point(287, 209);
            this.BntSair.Name = "BntSair";
            this.BntSair.Size = new System.Drawing.Size(75, 23);
            this.BntSair.TabIndex = 6;
            this.BntSair.Text = "Sair";
            this.BntSair.UseVisualStyleBackColor = true;
            this.BntSair.Click += new System.EventHandler(this.button3_Click);
            // 
            // LblResult
            // 
            this.LblResult.AutoSize = true;
            this.LblResult.Location = new System.Drawing.Point(77, 158);
            this.LblResult.Name = "LblResult";
            this.LblResult.Size = new System.Drawing.Size(55, 13);
            this.LblResult.TabIndex = 8;
            this.LblResult.Text = "Resultado";
            // 
            // TxtResult
            // 
            this.TxtResult.Enabled = false;
            this.TxtResult.Location = new System.Drawing.Point(158, 155);
            this.TxtResult.Name = "TxtResult";
            this.TxtResult.Size = new System.Drawing.Size(100, 20);
            this.TxtResult.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(660, 360);
            this.Controls.Add(this.TxtResult);
            this.Controls.Add(this.LblResult);
            this.Controls.Add(this.BntSair);
            this.Controls.Add(this.BntLimpar);
            this.Controls.Add(this.TxtPeso);
            this.Controls.Add(this.LblAltura);
            this.Controls.Add(this.TxtAltura);
            this.Controls.Add(this.BntCalc);
            this.Controls.Add(this.LblPeso);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblPeso;
        private System.Windows.Forms.Button BntCalc;
        private System.Windows.Forms.TextBox TxtAltura;
        private System.Windows.Forms.Label LblAltura;
        private System.Windows.Forms.TextBox TxtPeso;
        private System.Windows.Forms.Button BntLimpar;
        private System.Windows.Forms.Button BntSair;
        private System.Windows.Forms.Label LblResult;
        private System.Windows.Forms.TextBox TxtResult;
    }
}

