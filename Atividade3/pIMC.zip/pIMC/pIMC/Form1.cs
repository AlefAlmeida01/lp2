﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pIMC
{
    public partial class Form1 : Form
    {
        double Imc, altura, peso;
        public Form1()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BntLimpar_Click(object sender, EventArgs e)
        {
            TxtAltura.Clear();
            TxtPeso.Clear();
            TxtResult.Clear();
        }

        private void BntCalc_Click(object sender, EventArgs e)
        {
            if(double.TryParse(TxtAltura.Text, out altura) &&
               double.TryParse(TxtPeso.Text, out peso))
            {
                if ((altura<=0) || (peso<=0))
                    MessageBox.Show("O peso e a altura devem ser superiores a zero");
                else
                {
                    Imc = peso / (Math.Pow(altura, 2));
                    Imc = Math.Round(Imc, 1);

                    TxtResult.Text = Imc.ToString("N1");

                    if (Imc < 18.5)
                        MessageBox.Show("Magreza");
                    else if (Imc <= 24.9)
                        MessageBox.Show("Normal");
                    else if (Imc <= 29.9)
                        MessageBox.Show("Sobre peso");
                    else if (Imc <= 39.9)
                        MessageBox.Show("Obesidade");
                    else
                        MessageBox.Show("Obesidade grave");
                }
                
            }

        }
    }
}
