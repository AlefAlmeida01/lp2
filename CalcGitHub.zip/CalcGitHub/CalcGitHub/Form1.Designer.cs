﻿
namespace CalcGitHub
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtResult = new System.Windows.Forms.TextBox();
            this.BntLimpar = new System.Windows.Forms.Button();
            this.BntDiv = new System.Windows.Forms.Button();
            this.BntMult = new System.Windows.Forms.Button();
            this.BntSub = new System.Windows.Forms.Button();
            this.BntSomar = new System.Windows.Forms.Button();
            this.txtNum2 = new System.Windows.Forms.TextBox();
            this.LblResultado = new System.Windows.Forms.Label();
            this.LblNum2 = new System.Windows.Forms.Label();
            this.LblNum1 = new System.Windows.Forms.Label();
            this.txtNum1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.BntSair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtResult
            // 
            this.txtResult.Enabled = false;
            this.txtResult.Location = new System.Drawing.Point(148, 194);
            this.txtResult.Name = "txtResult";
            this.txtResult.Size = new System.Drawing.Size(108, 20);
            this.txtResult.TabIndex = 39;
            // 
            // BntLimpar
            // 
            this.BntLimpar.Location = new System.Drawing.Point(455, 170);
            this.BntLimpar.Name = "BntLimpar";
            this.BntLimpar.Size = new System.Drawing.Size(87, 23);
            this.BntLimpar.TabIndex = 8;
            this.BntLimpar.Text = "Limpar";
            this.BntLimpar.UseVisualStyleBackColor = true;
            this.BntLimpar.Click += new System.EventHandler(this.BntLimpar_Click);
            // 
            // BntDiv
            // 
            this.BntDiv.Location = new System.Drawing.Point(455, 287);
            this.BntDiv.Name = "BntDiv";
            this.BntDiv.Size = new System.Drawing.Size(87, 23);
            this.BntDiv.TabIndex = 7;
            this.BntDiv.Text = "Divisão";
            this.BntDiv.UseVisualStyleBackColor = true;
            this.BntDiv.Click += new System.EventHandler(this.BntDiv_Click);
            // 
            // BntMult
            // 
            this.BntMult.Location = new System.Drawing.Point(328, 287);
            this.BntMult.Name = "BntMult";
            this.BntMult.Size = new System.Drawing.Size(87, 23);
            this.BntMult.TabIndex = 6;
            this.BntMult.Text = "Multiplicar";
            this.BntMult.UseVisualStyleBackColor = true;
            this.BntMult.Click += new System.EventHandler(this.BntMult_Click);
            // 
            // BntSub
            // 
            this.BntSub.Location = new System.Drawing.Point(201, 287);
            this.BntSub.Name = "BntSub";
            this.BntSub.Size = new System.Drawing.Size(87, 23);
            this.BntSub.TabIndex = 5;
            this.BntSub.Text = "Subtrair";
            this.BntSub.UseVisualStyleBackColor = true;
            this.BntSub.Click += new System.EventHandler(this.BntSub_Click);
            // 
            // BntSomar
            // 
            this.BntSomar.Location = new System.Drawing.Point(73, 287);
            this.BntSomar.Name = "BntSomar";
            this.BntSomar.Size = new System.Drawing.Size(87, 23);
            this.BntSomar.TabIndex = 4;
            this.BntSomar.Text = "Somar";
            this.BntSomar.UseVisualStyleBackColor = true;
            this.BntSomar.Click += new System.EventHandler(this.BntSomar_Click);
            // 
            // txtNum2
            // 
            this.txtNum2.Location = new System.Drawing.Point(148, 142);
            this.txtNum2.Name = "txtNum2";
            this.txtNum2.Size = new System.Drawing.Size(108, 20);
            this.txtNum2.TabIndex = 3;
            // 
            // LblResultado
            // 
            this.LblResultado.AutoSize = true;
            this.LblResultado.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.LblResultado.Image = global::CalcGitHub.Properties.Resources._69a8c3699e987289900a34e74516246b;
            this.LblResultado.Location = new System.Drawing.Point(70, 197);
            this.LblResultado.Name = "LblResultado";
            this.LblResultado.Size = new System.Drawing.Size(58, 13);
            this.LblResultado.TabIndex = 32;
            this.LblResultado.Text = "Resultado:";
            // 
            // LblNum2
            // 
            this.LblNum2.AutoSize = true;
            this.LblNum2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.LblNum2.Image = global::CalcGitHub.Properties.Resources._69a8c3699e987289900a34e74516246b;
            this.LblNum2.Location = new System.Drawing.Point(70, 145);
            this.LblNum2.Name = "LblNum2";
            this.LblNum2.Size = new System.Drawing.Size(56, 13);
            this.LblNum2.TabIndex = 31;
            this.LblNum2.Text = "Número 2:";
            // 
            // LblNum1
            // 
            this.LblNum1.AutoSize = true;
            this.LblNum1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.LblNum1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.LblNum1.Image = global::CalcGitHub.Properties.Resources._69a8c3699e987289900a34e74516246b;
            this.LblNum1.Location = new System.Drawing.Point(70, 97);
            this.LblNum1.Name = "LblNum1";
            this.LblNum1.Size = new System.Drawing.Size(56, 13);
            this.LblNum1.TabIndex = 30;
            this.LblNum1.Text = "Número 1:";
            // 
            // txtNum1
            // 
            this.txtNum1.Location = new System.Drawing.Point(148, 94);
            this.txtNum1.Name = "txtNum1";
            this.txtNum1.Size = new System.Drawing.Size(108, 20);
            this.txtNum1.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(232, 127);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 28;
            // 
            // BntSair
            // 
            this.BntSair.Location = new System.Drawing.Point(455, 117);
            this.BntSair.Name = "BntSair";
            this.BntSair.Size = new System.Drawing.Size(87, 23);
            this.BntSair.TabIndex = 9;
            this.BntSair.Text = "Sair";
            this.BntSair.UseVisualStyleBackColor = true;
            this.BntSair.Click += new System.EventHandler(this.BntSair_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CalcGitHub.Properties.Resources._69a8c3699e987289900a34e74516246b;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtResult);
            this.Controls.Add(this.BntLimpar);
            this.Controls.Add(this.BntDiv);
            this.Controls.Add(this.BntMult);
            this.Controls.Add(this.BntSub);
            this.Controls.Add(this.BntSomar);
            this.Controls.Add(this.txtNum2);
            this.Controls.Add(this.LblResultado);
            this.Controls.Add(this.LblNum2);
            this.Controls.Add(this.LblNum1);
            this.Controls.Add(this.txtNum1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BntSair);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtResult;
        private System.Windows.Forms.Button BntLimpar;
        private System.Windows.Forms.Button BntDiv;
        private System.Windows.Forms.Button BntMult;
        private System.Windows.Forms.Button BntSub;
        private System.Windows.Forms.Button BntSomar;
        private System.Windows.Forms.TextBox txtNum2;
        private System.Windows.Forms.Label LblResultado;
        private System.Windows.Forms.Label LblNum2;
        private System.Windows.Forms.Label LblNum1;
        private System.Windows.Forms.TextBox txtNum1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button BntSair;
    }
}

