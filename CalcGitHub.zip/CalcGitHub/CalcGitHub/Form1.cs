﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalcGitHub
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BntSomar_Click(object sender, EventArgs e)
        {
            int num1, num2, Resultado;

            num1 = Convert.ToInt32(txtNum1.Text);

            num2 = Convert.ToInt32(txtNum2.Text);

            Resultado = num1 + num2;

            txtResult.Text = Convert.ToString(Resultado);
        }

        private void BntSub_Click(object sender, EventArgs e)
        {
            int num1, num2, Resultado;

            num1 = Convert.ToInt32(txtNum1.Text);

            num2 = Convert.ToInt32(txtNum2.Text);

            Resultado = num1 - num2;

            txtResult.Text = Convert.ToString(Resultado);
        }

        private void BntMult_Click(object sender, EventArgs e)
        {
            int num1, num2, Resultado;

            num1 = Convert.ToInt32(txtNum1.Text);

            num2 = Convert.ToInt32(txtNum2.Text);

            Resultado = num1 * num2;

            txtResult.Text = Convert.ToString(Resultado);
        }

        private void BntDiv_Click(object sender, EventArgs e)
        {
            int num1, num2, Resultado;

            num1 = Convert.ToInt32(txtNum1.Text);

            num2 = Convert.ToInt32(txtNum2.Text);

            Resultado = num1 / num2;

            txtResult.Text = Convert.ToString(Resultado);
        }

        private void BntLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Clear();
            txtNum2.Clear();
            txtResult.Clear();
        }

        private void BntSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
