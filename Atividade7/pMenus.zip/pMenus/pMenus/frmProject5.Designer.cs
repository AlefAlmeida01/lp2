﻿namespace pMenus
{
    partial class frmProject5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TxtPalavra1 = new System.Windows.Forms.TextBox();
            this.TxtPalavra2 = new System.Windows.Forms.TextBox();
            this.LblPalavra1 = new System.Windows.Forms.Label();
            this.LblPalavra2 = new System.Windows.Forms.Label();
            this.BntAleatório = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // TxtPalavra1
            // 
            this.TxtPalavra1.Location = new System.Drawing.Point(272, 120);
            this.TxtPalavra1.Name = "TxtPalavra1";
            this.TxtPalavra1.Size = new System.Drawing.Size(100, 20);
            this.TxtPalavra1.TabIndex = 0;
            // 
            // TxtPalavra2
            // 
            this.TxtPalavra2.Location = new System.Drawing.Point(272, 192);
            this.TxtPalavra2.Name = "TxtPalavra2";
            this.TxtPalavra2.Size = new System.Drawing.Size(100, 20);
            this.TxtPalavra2.TabIndex = 1;
            // 
            // LblPalavra1
            // 
            this.LblPalavra1.AutoSize = true;
            this.LblPalavra1.Location = new System.Drawing.Point(167, 123);
            this.LblPalavra1.Name = "LblPalavra1";
            this.LblPalavra1.Size = new System.Drawing.Size(52, 13);
            this.LblPalavra1.TabIndex = 2;
            this.LblPalavra1.Text = "Palavra 1";
            // 
            // LblPalavra2
            // 
            this.LblPalavra2.AutoSize = true;
            this.LblPalavra2.Location = new System.Drawing.Point(167, 195);
            this.LblPalavra2.Name = "LblPalavra2";
            this.LblPalavra2.Size = new System.Drawing.Size(52, 13);
            this.LblPalavra2.TabIndex = 3;
            this.LblPalavra2.Text = "Palavra 2";
            // 
            // BntAleatório
            // 
            this.BntAleatório.Location = new System.Drawing.Point(538, 120);
            this.BntAleatório.Name = "BntAleatório";
            this.BntAleatório.Size = new System.Drawing.Size(186, 102);
            this.BntAleatório.TabIndex = 4;
            this.BntAleatório.Text = "Escolha Aleatória";
            this.BntAleatório.UseVisualStyleBackColor = true;
            this.BntAleatório.Click += new System.EventHandler(this.BntAleatório_Click);
            // 
            // frmProject5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1532, 679);
            this.Controls.Add(this.BntAleatório);
            this.Controls.Add(this.LblPalavra2);
            this.Controls.Add(this.LblPalavra1);
            this.Controls.Add(this.TxtPalavra2);
            this.Controls.Add(this.TxtPalavra1);
            this.Name = "frmProject5";
            this.Text = "FrmProject5";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TxtPalavra1;
        private System.Windows.Forms.TextBox TxtPalavra2;
        private System.Windows.Forms.Label LblPalavra1;
        private System.Windows.Forms.Label LblPalavra2;
        private System.Windows.Forms.Button BntAleatório;
    }
}