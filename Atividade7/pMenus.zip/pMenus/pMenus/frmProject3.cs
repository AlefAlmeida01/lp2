﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pMenus
{
    public partial class frmProject3 : Form
    {
        public frmProject3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void bntInvert_Click(object sender, EventArgs e)
        {
            string auxiliar = txtPalavra1.Text;
            char[] arr = auxiliar.ToCharArray();
            Array.Reverse(arr);

            auxiliar = "";

            foreach (char cara in arr)
            {
                auxiliar = auxiliar + cara.ToString();
            }

            MessageBox.Show(auxiliar);
        }

        private void bntRemove2_Click(object sender, EventArgs e)
        {
            txtPalavra1.Text = txtPalavra1.Text.ToUpper();
            txtPalavra2.Text = txtPalavra2.Text.ToUpper();

            txtPalavra2.Text = txtPalavra2.Text.Replace(txtPalavra1.Text, "");
        }
    }
}
