﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pMenus
{
    public partial class frmProject4 : Form
    {
        public frmProject4()
        {
            InitializeComponent();
        }

        private void BntQuantNum_Click(object sender, EventArgs e)
        {
            double palavra;
            int cont;

            if (double.TryParse(RtbPalavra.Text, out palavra))
            {
                for (cont = 0; cont <= 10; cont++)
                    cont = cont + 1;

                public static bool IsNumber(char palavra);

                DialogResult dialogResult = MessageBox.Show(palavra);
            }
    }

        private void BntCharNum1_Click(object sender, EventArgs e)
        {
            char palavra[10];

            while(palavra<=10)
            {
                if (char.IsWhiteSpace)
                {
                    palavra = palavra[0];
                }
                Console.WriteLine(palavra.ToString());
            }
        }

        private void BntQuantChar_Click(object sender, EventArgs e)
        {
            char palavra;
            int cont;

            for(cont=0;cont<10;cont++)
            {
                if (char.IsLetter)
                return palavra;
            }

        }
    }
