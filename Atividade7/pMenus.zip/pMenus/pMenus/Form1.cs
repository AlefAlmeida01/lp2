﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pMenus
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exercício2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["frmProject2"];
            if (fc != null)
                fc.Close();
            
            frmProject2 frm2 = new frmProject2();
            frm2.MdiParent = this;
            frm2.WindowState = FormWindowState.Maximized;
            frm2.Show();

            Form fc = Application.OpenForms["frmProject3"];
            if (fc != null)
                fc.Close();

            frmProject2 frm3 = new frmProject2();
            frm3.MdiParent = this;
            frm3.WindowState = FormWindowState.Maximized;
            frm3.Show();

            Form fc = Application.OpenForms["frmProject4"];
            if (fc != null)
                fc.Close();

            frmProject2 frm4 = new frmProject2();
            frm4.MdiParent = this;
            frm4.WindowState = FormWindowState.Maximized;
            frm4.Show();

            Form fc = Application.OpenForms["frmProject5"];
            if (fc != null)
                fc.Close();

            frmProject2 frm5 = new frmProject2();
            frm5.MdiParent = this;
            frm5.WindowState = FormWindowState.Maximized;
            frm5.Show();


        }

        private void copiarCtrlcToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Teclou Ctrl + C");
        }

        private void colarCtrlVToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Teclou Ctrl + V");
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
