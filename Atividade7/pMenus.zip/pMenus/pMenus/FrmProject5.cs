﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pMenus
{
    public partial class frmProject5 : Form
    {
        public frmProject5()
        {
            InitializeComponent();
        }

        private void BntAleatório_Click(object sender, EventArgs e)
        {
            double p1, p2;

            if (double.TryParse(TxtPalavra1.Text, out p1) &&
                double.TryParse(TxtPalavra2.Text, out p2))
            {

                Random randNum = new Random();
                randNum.Next(p1, (double)p2);
            }
        }
    }
}
