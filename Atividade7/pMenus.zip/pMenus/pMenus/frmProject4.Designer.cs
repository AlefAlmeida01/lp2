﻿namespace pMenus
{
    partial class frmProject4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.RtbPalavra = new System.Windows.Forms.RichTextBox();
            this.BntQuantNum = new System.Windows.Forms.Button();
            this.BntCharNum1 = new System.Windows.Forms.Button();
            this.BntQuantChar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // RtbPalavra
            // 
            this.RtbPalavra.Location = new System.Drawing.Point(207, 92);
            this.RtbPalavra.Name = "RtbPalavra";
            this.RtbPalavra.Size = new System.Drawing.Size(117, 30);
            this.RtbPalavra.TabIndex = 0;
            this.RtbPalavra.Text = "";
            // 
            // BntQuantNum
            // 
            this.BntQuantNum.Location = new System.Drawing.Point(207, 235);
            this.BntQuantNum.Name = "BntQuantNum";
            this.BntQuantNum.Size = new System.Drawing.Size(174, 92);
            this.BntQuantNum.TabIndex = 1;
            this.BntQuantNum.Text = "Quantos Números";
            this.BntQuantNum.UseVisualStyleBackColor = true;
            this.BntQuantNum.Click += new System.EventHandler(this.BntQuantNum_Click);
            // 
            // BntCharNum1
            // 
            this.BntCharNum1.Location = new System.Drawing.Point(568, 235);
            this.BntCharNum1.Name = "BntCharNum1";
            this.BntCharNum1.Size = new System.Drawing.Size(174, 92);
            this.BntCharNum1.TabIndex = 2;
            this.BntCharNum1.Text = "1º caracter";
            this.BntCharNum1.UseVisualStyleBackColor = true;
            this.BntCharNum1.Click += new System.EventHandler(this.BntCharNum1_Click);
            // 
            // BntQuantChar
            // 
            this.BntQuantChar.Location = new System.Drawing.Point(970, 235);
            this.BntQuantChar.Name = "BntQuantChar";
            this.BntQuantChar.Size = new System.Drawing.Size(174, 92);
            this.BntQuantChar.TabIndex = 3;
            this.BntQuantChar.Text = "Quantos Caracteres";
            this.BntQuantChar.UseVisualStyleBackColor = true;
            this.BntQuantChar.Click += new System.EventHandler(this.BntQuantChar_Click);
            // 
            // frmProject4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1551, 688);
            this.Controls.Add(this.BntQuantChar);
            this.Controls.Add(this.BntCharNum1);
            this.Controls.Add(this.BntQuantNum);
            this.Controls.Add(this.RtbPalavra);
            this.Name = "frmProject4";
            this.Text = "FrmProject4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox RtbPalavra;
        private System.Windows.Forms.Button BntQuantNum;
        private System.Windows.Forms.Button BntCharNum1;
        private System.Windows.Forms.Button BntQuantChar;
    }
}