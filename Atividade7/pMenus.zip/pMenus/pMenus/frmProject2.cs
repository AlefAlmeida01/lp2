﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pMenus
{
    public partial class frmProject2 : Form
    {
        public frmProject2()
        {
            InitializeComponent();
        }

        private void bntIguais_Click(object sender, EventArgs e)
        {
            if(string.Compare(txtPalavra1.Text,
                txtPalavra2.Text, true) == 0)
                MessageBox.Show("São iguais!");
            else
                MessageBox.Show("São Diferentes!");
        }

        private void bntInserir_Click(object sender, EventArgs e)
        {
            int meio = txtPalavra2.Text.Length / 2;
            txtPalavra2.Text = txtPalavra2.Text.Substring(0, meio) +
                txtPalavra1.Text + txtPalavra2.Text.Substring(meio, 
            txtPalavra2.Text.Length - meio);
        }

        private void bntAsteriscos_Click(object sender, EventArgs e)
        {
            int meio = txtPalavra2.Text.Length / 2;
            txtPalavra2.Text = txtPalavra1.Text.Insert(meio, "**");
        }
    }
}
