﻿namespace pTesteClasses
{
    partial class frmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TxtMatric = new System.Windows.Forms.Label();
            this.TxtNome = new System.Windows.Forms.Label();
            this.TxtSalHora = new System.Windows.Forms.Label();
            this.TxtEntEmp = new System.Windows.Forms.Label();
            this.BntInstMens = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.TxtDataEntEmp = new System.Windows.Forms.Label();
            this.TxtDiasFalt = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // TxtMatric
            // 
            this.TxtMatric.AutoSize = true;
            this.TxtMatric.Location = new System.Drawing.Point(311, 114);
            this.TxtMatric.Name = "TxtMatric";
            this.TxtMatric.Size = new System.Drawing.Size(52, 13);
            this.TxtMatric.TabIndex = 0;
            this.TxtMatric.Text = "Matrícula";
            // 
            // TxtNome
            // 
            this.TxtNome.AutoSize = true;
            this.TxtNome.Location = new System.Drawing.Point(311, 156);
            this.TxtNome.Name = "TxtNome";
            this.TxtNome.Size = new System.Drawing.Size(35, 13);
            this.TxtNome.TabIndex = 1;
            this.TxtNome.Text = "Nome";
            // 
            // TxtSalHora
            // 
            this.TxtSalHora.AutoSize = true;
            this.TxtSalHora.Location = new System.Drawing.Point(311, 190);
            this.TxtSalHora.Name = "TxtSalHora";
            this.TxtSalHora.Size = new System.Drawing.Size(83, 13);
            this.TxtSalHora.TabIndex = 2;
            this.TxtSalHora.Text = "Salário por Hora";
            // 
            // TxtEntEmp
            // 
            this.TxtEntEmp.AutoSize = true;
            this.TxtEntEmp.Location = new System.Drawing.Point(311, 228);
            this.TxtEntEmp.Name = "TxtEntEmp";
            this.TxtEntEmp.Size = new System.Drawing.Size(88, 13);
            this.TxtEntEmp.TabIndex = 3;
            this.TxtEntEmp.Text = "Número de horas";
            // 
            // BntInstMens
            // 
            this.BntInstMens.Location = new System.Drawing.Point(566, 414);
            this.BntInstMens.Name = "BntInstMens";
            this.BntInstMens.Size = new System.Drawing.Size(169, 82);
            this.BntInstMens.TabIndex = 4;
            this.BntInstMens.Text = "Instanciar Horista";
            this.BntInstMens.UseVisualStyleBackColor = true;
            this.BntInstMens.Click += new System.EventHandler(this.BntInstMens_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(628, 111);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(122, 20);
            this.textBox1.TabIndex = 6;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(628, 187);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(122, 20);
            this.textBox2.TabIndex = 7;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(628, 225);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(122, 20);
            this.textBox3.TabIndex = 8;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(628, 153);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(122, 20);
            this.textBox4.TabIndex = 9;
            // 
            // TxtDataEntEmp
            // 
            this.TxtDataEntEmp.AutoSize = true;
            this.TxtDataEntEmp.Location = new System.Drawing.Point(314, 268);
            this.TxtDataEntEmp.Name = "TxtDataEntEmp";
            this.TxtDataEntEmp.Size = new System.Drawing.Size(129, 13);
            this.TxtDataEntEmp.TabIndex = 11;
            this.TxtDataEntEmp.Text = "Data Entrada na Empresa";
            // 
            // TxtDiasFalt
            // 
            this.TxtDiasFalt.AutoSize = true;
            this.TxtDiasFalt.Location = new System.Drawing.Point(314, 317);
            this.TxtDiasFalt.Name = "TxtDiasFalt";
            this.TxtDiasFalt.Size = new System.Drawing.Size(74, 13);
            this.TxtDiasFalt.TabIndex = 12;
            this.TxtDiasFalt.Text = "Dias de Faltas";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(628, 265);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(122, 20);
            this.textBox5.TabIndex = 13;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(628, 314);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(122, 20);
            this.textBox6.TabIndex = 14;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioButton2);
            this.groupBox1.Controls.Add(this.radioButton1);
            this.groupBox1.Location = new System.Drawing.Point(986, 139);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 100);
            this.groupBox1.TabIndex = 16;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tabalha em Home Office";
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(6, 28);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(44, 17);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "SIM";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(6, 51);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(48, 17);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "NÃO";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1471, 637);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.TxtDiasFalt);
            this.Controls.Add(this.TxtDataEntEmp);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.BntInstMens);
            this.Controls.Add(this.TxtEntEmp);
            this.Controls.Add(this.TxtSalHora);
            this.Controls.Add(this.TxtNome);
            this.Controls.Add(this.TxtMatric);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label TxtMatric;
        private System.Windows.Forms.Label TxtNome;
        private System.Windows.Forms.Label TxtSalHora;
        private System.Windows.Forms.Label TxtEntEmp;
        private System.Windows.Forms.Button BntInstMens;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label TxtDataEntEmp;
        private System.Windows.Forms.Label TxtDiasFalt;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
    }
}

